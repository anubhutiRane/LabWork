package com.capgemini.training.lab8.Exercise1;


public class FileProgram {

		public static void main(String[] args) {
			System.out.println(Thread.currentThread()); 
			Thread t1= new CopyDataThread("worker1");
			t1.start();
			
			

		}

	
	
}
