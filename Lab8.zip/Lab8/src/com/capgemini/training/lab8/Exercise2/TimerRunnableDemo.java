package com.capgemini.training.lab8.Exercise2;

public class TimerRunnableDemo {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread());
        //Runnable object
        Runnable runnable= new TimerRunnable();
        
        Thread t1= new Thread(runnable,"worker-1");
        t1.start();
           
	
	}
}

