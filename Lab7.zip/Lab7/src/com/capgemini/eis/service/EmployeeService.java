package com.capgemini.eis.service;

import java.util.List;

import com.capgemini.eis.bean.Employee;
import com.capgemini.eis.exception.EmployeeException;

public interface EmployeeService {
	public Integer addEmployee(Employee employee) throws EmployeeException;
	public Integer deleteEmployee(Integer empid) throws EmployeeException;
	public List<Employee> 
	getEmployeesByInsuranceScheme(String insuranceScheme) 
			throws EmployeeException;
	
	public List<Employee> getAllEmployees() throws EmployeeException;
}
