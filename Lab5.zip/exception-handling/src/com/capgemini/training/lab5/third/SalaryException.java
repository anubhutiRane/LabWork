package com.capgemini.training.lab5.third;
public class SalaryException extends Exception {
	private String message;

	public SalaryException() {

	}

	public SalaryException(String message) {
		this.message=message;
	}
	
	public String getMessage() {
		return this.message;
	}


}