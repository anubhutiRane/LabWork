package com.capgemini.training.lab5.third;
import java.util.Scanner;

public class SalaryTester {
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		try {
			System.out.println("Enter your salary: ");
			double sal= scanner.nextDouble();
			if(sal<3000) {
				throw new SalaryException("Salary is below 3000");
			}
			System.out.println("Salary is okay");

		}catch(SalaryException e) {
			e.printStackTrace();
		}

	}

}