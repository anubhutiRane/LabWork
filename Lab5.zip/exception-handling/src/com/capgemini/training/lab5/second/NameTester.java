package com.capgemini.training.lab5.second;
import java.util.Scanner;


public class NameTester {
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		try {
			System.out.println("Enter your first name: ");
			String fname = scanner.nextLine();
			System.out.println("Enter your last name: ");
			String lname = scanner.nextLine();
			
			if(fname.isEmpty() || lname.isEmpty()) {
				throw new NameException("Your name is not entered.");
			}
			else{
				System.out.println("Your name is " +fname +" " +lname);
			}

		}catch(NameException e) {
			e.printStackTrace();
		}

	}

}