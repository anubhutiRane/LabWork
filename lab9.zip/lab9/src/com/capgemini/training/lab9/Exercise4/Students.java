package com.capgemini.training.lab9.Exercise4;

public class Students {
	   private String name;
	    
	   Students()
	    {
	        System.out.println("Default Constructor");
	    }
	    Students(String name) 
	    {
	         this.name = name;
	    }
	    
	    public String toString() {
	        return "name: " + name;
	    }
}
