package com.capgemini.training.lab9.Exercise4;

public interface Student {
	Students get(String name);
}
