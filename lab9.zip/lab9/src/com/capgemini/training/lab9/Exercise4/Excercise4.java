package com.capgemini.training.lab9.Exercise4;

import java.util.Scanner;

public class Excercise4 {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) 

{ 
		Student studentName= Students::new ;
		System.out.println("Enter the name of the student : ");
	    System.out.println(studentName.get(sc.nextLine()));
	 
}
}
