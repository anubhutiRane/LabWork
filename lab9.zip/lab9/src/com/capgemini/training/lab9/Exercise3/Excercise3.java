package com.capgemini.training.lab9.Exercise3;

import java.util.Scanner;

@FunctionalInterface
interface valid
{
	boolean authentication(String str1,String str2);
}

public class Excercise3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter username");
		String str1 = sc.next();

		System.out.println("Enter password");
		String str2 = sc.next();

		valid validity=(a,b)->a.equals("user") && b.equals("root");

		System.out.println("The validity of account is : "+validity.authentication(str1, str2));

	}
}

