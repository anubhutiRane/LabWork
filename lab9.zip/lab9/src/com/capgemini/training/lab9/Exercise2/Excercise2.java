package com.capgemini.training.lab9.Exercise2;

import java.util.Scanner;

interface AddSpace
{
	String spacemethod(String str);
}

public class Excercise2 {
	
	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter a string ");
	String str = sc.nextLine();
	
	AddSpace spacedString=(inp)->inp.replaceAll(".", "$0 ");
	System.out.println("Space added string is : "+spacedString.spacemethod(str));
		
}
}
