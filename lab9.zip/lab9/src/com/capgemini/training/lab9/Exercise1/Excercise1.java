package com.capgemini.training.lab9.Exercise1;

import java.util.Scanner;

interface PowerOfNum
{
	double power(int x,int y);

}

public  class Excercise1 {
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Enter the value of the number you want the power of : ");
		int number=sc.nextInt();
		
		System.out.println("Enter the power value : ");
		int powerValue=sc.nextInt();
		
		PowerOfNum pon = (x,y)->Math.pow(x,y);
		double answer= pon.power(number,powerValue);
		
		System.out.print(answer);

	}


}
