import java.util.*;
import java.lang.*;

public class One {

	public static int sumOfCubes(int number) {
		int sum = 0;
		while(number>0){
	        int t= number%10;
	        t = t*t*t;
	        sum +=t;
	        number = number/10;

	    }
		return sum;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = scanner.nextInt();
		System.out.println(sumOfCubes(n));

	}
}