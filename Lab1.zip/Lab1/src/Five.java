

import java.util.Scanner;

public class Five {
	
	private static Scanner sc = new Scanner(System.in);
	public static void main (String[] args) {
	System.out.println("Enter a number");
	int n = sc.nextInt();
	long sun = calculateSum(n);
	}
	private static long calculateSum(int n) {
		// TODO Auto-generated method stub
		long sum = 0;
		for(int i = 1; i <n;i++) {
			if(i%3==0 || i%5==0) {
				sum = sum+=i;
			}
		}
		return 0;
	}
	
}
//		static int calculateSum(int N)  
//		{  
//		    int S1, S2, S3;  
//		  //Sn = (n/2) * {2*a + (n-1)*d}
//
//		    S1 = ((N / 3)) * (2 * 3 + (N / 3 - 1) * 3) / 2;  
//		    S2 = ((N / 5)) * (2 * 5 + (N / 5 - 1) * 5) / 2;  
//		    S3 = ((N / 15)) * (2 * 15 + (N / 15 - 1) * 15) / 2;  
//		  
//		    return S1 + S2 - S3;  
//		}  
//		  
//		
//		 public static void main (String[] args) { 
//		 Scanner sc = new Scanner(System.in);
//		     
//		  System.out.println("Enter the value of N");
//		  int N = sc.nextInt(); 
//		    System.out.print(calculateSum(15));  
//		} 
//		  
//		}  
//		