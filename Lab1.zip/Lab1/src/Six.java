

import java.util.Scanner;

public class Six {
		  
		static int calculateDifference(int n){ 
		  
		int l, k, m; 
		    // sum of n^2 = [n(n+1)(2n+1)]/6
		    l = (n * (n + 1) * (2 * n + 1)) / 6; 
		      
		    // Sum of n naturals numbers 
		    k = (n * (n + 1)) / 2; 
		  
		    // Square of sum 
		    k = k * k; 
		      
		    // Differences between l and k 
		    m = Math.abs(l - k); 
		      
		    return m; 
		  
		} 
		 
		public static void main(String s[]) 
		{ 
			Scanner sc = new Scanner(System.in);
		    System.out.println("Enter the value of N");
			int N = sc.nextInt(); 
		    System.out.println(calculateDifference(N));      
		      
		} 
		}  