

import java.util.Scanner;

public class Eight {

	static boolean checkNumber(int n)
	{
	    if(n==0)
	    return false;
	 
	return (int)(Math.ceil((Math.log(n) / Math.log(2)))) == 
	       (int)(Math.floor(((Math.log(n) / Math.log(2)))));
	}
	 
	public static void main(String[] args)
	{
		
		System.out.println("Enter the number to be checked");
		Scanner scanner = new Scanner(System.in);
		int   num = scanner.nextInt();
		
	    if(checkNumber(num))
	    System.out.println("Yes");
	    else
	    System.out.println("No");
	}
	}