package com.capgemini.lab3;


import java.util.Arrays;
import java.util.Scanner;

public class Exercise8 {
	static boolean isInOrder(String s)  
    {  
        int strLen = s.length();  
        char charArray[] = new char [strLen];  
  
        for (int i = 0; i < strLen; i++) {  
            charArray[i] = s.charAt(i);  
        }  
        
        // sort the character array  
        Arrays.sort(charArray);  
       
        for (int i = 0; i < strLen; i++)  
            if (charArray[i] != s.charAt(i))   
                return false;  
                
        return true;      
    }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in); 
		System.out.print("Enter a string: ");  
		String s= sc.nextLine(); 
        if (isInOrder(s))  
            System.out.println("True");  
         else
             System.out.println("false");  
             
	}

}