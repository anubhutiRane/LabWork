package com.capgemini.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Excercise5 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string:");
		String inputString=sc.nextLine();
		
		System.out.println("The string entered is :"+inputString);
		
		int countChar=inputString.replace(" ","").length();
		
		System.out.println("Number of characters is :"+countChar);
		
		String[]words=inputString.split(" ");
		Arrays.toString(words);
		int wordCount=words.length;
		System.out.println("Number of words is :"+wordCount);
		
		String[]lines=inputString.split("[!?.:]+");
		Arrays.toString(lines);
		int lineCount=lines.length;
		System.out.println("Number of lines is :"+lineCount);
	}
}