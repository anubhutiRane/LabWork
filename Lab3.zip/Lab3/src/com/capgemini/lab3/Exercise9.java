package com.capgemini.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import java.util.Scanner;

public class Exercise9 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);


		System.out.println("Enter year in YYYY format :");
		int year=sc.nextInt();

		System.out.println("Enter month in MM format : ");
		int month=sc.nextInt();

		System.out.println("Enter day in DD format : ");
		int date=sc.nextInt();

		LocalDate pdate=LocalDate.of(year, month, date);
		System.out.println("Entered date is : ");
		System.out.println(pdate);
		System.out.println("Current date is : ");
		LocalDate now=LocalDate.now();
		System.out.println(now);

		Period diff=Period.between(pdate,now);

		System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
				diff.getYears(), diff.getMonths(), diff.getDays());
	}


}