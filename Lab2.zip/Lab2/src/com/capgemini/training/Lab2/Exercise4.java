package com.capgemini.training.Lab2;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise4 {

	static int removeDuplicates(int arr[], int n) 
	{ 
		if (n == 0 || n == 1) 
			return n; 
		int j = 0; 

		for (int i = 0; i < n-1; i++) 
			if (arr[i] != arr[i+1]) 
				arr[j++] = arr[i]; 

		arr[j++] = arr[n-1]; 

		return j; 
	} 

	public static void main (String[] args)  
	{ 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array size");
		int size = sc.nextInt();
		int arr[] = new int[size];
		for(int i = 0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		Arrays.sort(arr);
		int n = arr.length; 

		n = removeDuplicates(arr, n); 

		// Print updated array 
		for (int i=n-1; i>0; i--) 
			System.out.print(arr[i]+" "); 
	} 
} 