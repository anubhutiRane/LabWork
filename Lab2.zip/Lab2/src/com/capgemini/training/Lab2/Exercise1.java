package com.capgemini.training.Lab2;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise1 {
	public static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the size of array");
		int size = sc.nextInt();
		int integersArray[] = new int[size];
		
		int secondSmallest = getSecongSmallest(size, integersArray);
		System.out.println("The second smallest array is : " +secondSmallest);
	}
	
	private static int getSecongSmallest(int size, int[] integersArray) {
		System.out.println("Enter " +size +" elements");
		for(int i = 0; i <integersArray.length;i++) {
			integersArray[i] = sc.nextInt();
		}
		
		Arrays.sort(integersArray);
		return integersArray[1];
	}

}
