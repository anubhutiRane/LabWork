package com.capgemini.training.Lab4.Exercise3.service;


public class CD extends MediaItem
{
	private String artist, CDgenre;
	
	public CD(int idNum, String title, int numberOfCopies, int runningTime, String artists, String genreOfCD) {
		super(idNum, title, numberOfCopies, runningTime);
		this.artist = artists;
		this.CDgenre = genreOfCD;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getCDgenre() {
		return CDgenre;
	}

	public void setCDgenre(String cDgenre) {
		CDgenre = cDgenre;
	}
	
	@Override
	public void print() 
	{
		super.print();
		System.out.println("Artist: " + artist);
		System.out.println("Genre: " + CDgenre);
	}
}
