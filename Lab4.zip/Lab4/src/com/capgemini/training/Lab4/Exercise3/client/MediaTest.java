package com.capgemini.training.Lab4.Exercise3.client;

import com.capgemini.training.Lab4.Exercise3.service.CD;

public class MediaTest {

	public static void main(String[] args) {
		CD cd = new CD(1, "Titanic", 3, 20, "Jack and Rose", "Documentary");
		cd.print();
		cd.checkOut();
		cd.print();
		
	}

}
