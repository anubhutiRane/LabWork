package com.capgemini.training.Lab4.Exercise2.service;

import com.capgemini.training.Lab4.Exercise2.bean.Employee;

public interface EmployeeService {
	
	public abstract void getEmployeeDetails(Employee emp);
	public abstract String findInsuranceScheme(Employee emp);
	public abstract void showEmployeeDetails(Employee emp);
	
}
