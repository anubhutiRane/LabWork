package com.capgemini.training.Lab4.Exercise2.bean;

public enum Designation {
	SYSTEM_ASSOCIATE, MANAGER, PROGRAMMER, CRERK
}
