package com.capgemini.training.Lab4.Exercise2.eis.pl;

import com.capgemini.training.Lab4.Exercise2.bean.Employee;
import com.capgemini.training.Lab4.Exercise2.service.EmployeeService;
import com.capgemini.training.Lab4.Exercise2.service.EmployeeServiceImpl;

public class EmployeeDetails {

	public static void main(String[] args) {
		
		Employee employee = new Employee();
		EmployeeService emp = new EmployeeServiceImpl(); 
		emp.getEmployeeDetails(employee);
		System.out.println("Insurance Scheme applicable is: "+emp.findInsuranceScheme(employee));
		emp.showEmployeeDetails(employee);
	}

}
