package com.capgemini.lab4.Exercise1.service;

public class CurrentAccount extends Account {
	  private double overDraftLimit;
	  
	  public void withdraw(double amt)
		{
			if(amt<overDraftLimit)
			    System.out.println("You can withdraw!");
			else
				System.out.println("You have reached the limit!.. You can't withdraw anymore.");
		}
	  
	}
