package com.capgemini.lab4.Exercise1.client;

import com.capgemini.lab4.Exercise1.service.Account;
import com.capgemini.lab4.Exercise1.service.Person;
import com.capgemini.lab4.Exercise1.service.SavingAccount;

public class AccountDemo {

	public static void main(String[] args) {
		
		Account[] account = new SavingAccount[2];
		
		account[0] = new SavingAccount(101,2000.0,new Person("Smith",22));
     	account[1] = new SavingAccount(102,3000.0,new Person("Kathy",25));
     	
		System.out.println("Before the account was updated :");
		System.out.println("Account 1 :\n");
		account[0].display();
		System.out.println("Account 2 :\n");
		account[1].display();
		
		account[0].deposit(2000.0);
		account[1].withdraw(2000.0);
		
		System.out.println("____________________\n");
	
		System.out.println("After depositing and withdrawing :\n");
		System.out.println("Account 1 :");
		account[0].display();
		System.out.println("Account 2 :\n");
		account[1].display();
		
		System.out.println("Withdrawing from account 2 again :");
		account[1].withdraw(900.0);
		
	}

}
