package com.capgemini.training.lab6.Exercise7;

import java.util.Arrays;

public class Excercise7 {
//public static ArrayList<Integer> sortedArrayList(ArrayList<Integer> arr) {
//		Collections.sort(arr);
//		return arr;
//		
//	}

	public static void main(String args[]) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the size of the array: ");
//		int size=sc.nextInt();
//		int arrayNumbers[]=new int[size];
//        System.out.println("Enter the elements of the array");
//        for(int i=0;i<size;i++)
//        {
//            arrayNumbers[i]=sc.nextInt();
//        }
//		ArrayList<Integer> arr = new ArrayList<Integer>();
//		
		Integer [] list = new Integer[5];
		list[0] =20;
		list[1] =5;
		list[2]=15;
		list[3]=10;
		list[4] =53;
		
		getSorted(list);
		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i]);
		}
		
		
//		List<Integer> myList = Arrays.asList(list);
//		
//		Collections.reverse(myList);
//		Integer myArray[] = (Integer[])myList.toArray();
//		
//		Arrays.parallelSort(myArray);
//		
//		for(int i=0;i<arrayNumbers.length;i++)
//		{
//			arr.add(arrayNumbers[i]);
//		}
//		ArrayList<Integer> sorted=sortedArrayList(arr);
//		
//		for (int i = 0; i < sorted.size(); i++) {
//			  System.out.println(arr.get(i));
//		}
//		sc.close();
		
	}

private static void getSorted(Integer[] list) {
	String[] reverseNumbers = new String[list.length];
	for (int i = 0; i < list.length; i++) {
		reverseNumbers[i] = list[i].toString();
		StringBuffer sb = new StringBuffer(reverseNumbers[i]);
		reverseNumbers[i] = sb.reverse().toString();
		list[i] = Integer.parseInt(reverseNumbers[i]);
	}
	Arrays.sort(list);
	
}

}
